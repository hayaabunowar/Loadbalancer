package clientproject;

import java.io.IOException;
import java.net.InetAddress;
import java.util.Random;

public class ClientProject {

    private boolean nodesConnected = false;
    private int totalJobs = 1;
    private String jobMessage = "";

    private int clientPort;
    private InetAddress clientIPAddress;
    private int LBPort;
    private InetAddress LBIPAddress;

    //creating instance of messaging system
    ClientMessagingSystem clientMessagingSys = ClientMessagingSystem.getMessagingSystem();

    public void runClient() throws IOException, InterruptedException {

        //opening a socket with the port set through args
        clientMessagingSys.setClientPort(clientPort);

        System.out.println("---------------------------------------------------");
        System.out.println("\tClient is now running");
        System.out.println("\tClient IP Address: " + clientIPAddress);
        System.out.println("\tListening on port number: " + clientPort);
        System.out.println("---------------------------------------------------");

        //sending registration request to load balancer
        System.out.println("\nSending connection request to load balancer...");
        String connectionMessage = "CLIENT CONNECTION REQUEST, " + clientIPAddress + "," + clientPort;
        clientMessagingSys.sendMessage(connectionMessage, LBIPAddress, LBPort);

        //receiving connection successful message and nodes available message
        for (int i = 0; i < 2; i++) {
            String receivedMessage = clientMessagingSys.receiveMessage();
            messageType(receivedMessage);
        }

        //sending job requests to load balancer
        while (totalJobs <= 100 && nodesConnected) {
            String jobRequest = constructJobMessage();
            clientMessagingSys.sendMessage(jobRequest, LBIPAddress, LBPort);
            System.out.println("Job sent to load balancer: " + getJobMessage());
        }

    }

    //method to sort the message by type
    public void messageType(String receivedMessage) throws IOException, InterruptedException {
        String[] Message = receivedMessage.split(",");

        switch (Message[0]) {
            case "CONNECTED SUCCESSFULLY":
                System.out.println("CONNECTED TO LOAD BALANCER SUCCESSFULLY");
                break;
            case "NODES CONNECTED":
                System.out.println("\nNODES FOUND ON NETWORK, CLIENT WILL NOW SEND JOBS....");
                System.out.println("");
                nodesConnected = true;
                break;
        }
    }

    //method to create the job request
    public String constructJobMessage() {
        String jobID = Integer.toString(totalJobs);
        Random rand = new Random();
        String jobRuntime = Integer.toString(rand.nextInt(10) + 1);
        jobMessage = "JOB, " + jobID + ", " + jobRuntime;
        totalJobs++;
        return jobMessage;
    }

    //method to return the job request as a string for printing to console
    public String getJobMessage() {
        return jobMessage;
    }

    public void setLBIPAddress(InetAddress LBIPAddress) {
        this.LBIPAddress = LBIPAddress;
    }

    public void setLBPort(int LBPort) {
        this.LBPort = LBPort;
    }

    public void setClientPort(int clientPort) {
        this.clientPort = clientPort;
    }

    public void setClientIP(InetAddress clientIPAddress) {
        this.clientIPAddress = clientIPAddress;
    }

    public static void main(String[] args) throws IOException, InterruptedException {
        ClientProject client = new ClientProject();
        
        if (args.length == 4) {
            client.setLBPort(Integer.parseInt(args[0]));
            client.setLBIPAddress(InetAddress.getByName(args[1]));
            client.setClientPort(Integer.parseInt(args[2]));
            client.setClientIP(InetAddress.getByName(args[3]));       
        } else {
            client.setLBPort(Integer.parseInt("3000"));
            client.setLBIPAddress(InetAddress.getByName("localhost"));
            client.setClientPort(Integer.parseInt("2000"));
            client.setClientIP(InetAddress.getByName("localhost"));
        }
        
        client.runClient();
    }
}

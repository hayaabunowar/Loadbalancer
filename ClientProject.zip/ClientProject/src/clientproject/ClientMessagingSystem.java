package clientproject;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class ClientMessagingSystem {
    
    //making the class a singleton
    static ClientMessagingSystem ClientMessagingSys = null;

    private ClientMessagingSystem() {

    }

    public static ClientMessagingSystem getMessagingSystem() {
        if (ClientMessagingSys == null) {
            ClientMessagingSys = new ClientMessagingSystem();
        }
        return ClientMessagingSys;
    }
    
    //declaring socket
    private DatagramSocket socket = null;

    //defines the datagram socket to be opened
    public void setClientPort(int clientPort) throws SocketException {
        socket = new DatagramSocket(clientPort);
    }

    //method to send a message from the client
    public void sendMessage(String message, InetAddress LBIPAddress,int LBPort) throws IOException {
        socket.setSoTimeout(0);
        byte[] messageContents = new byte[256];
        messageContents = message.getBytes();
        DatagramPacket packet = new DatagramPacket(messageContents, messageContents.length, LBIPAddress, LBPort);
        socket.send(packet);
    }

    //method for client to receive a message
    public String receiveMessage() throws IOException {
        String message = "";
        byte[] messageContents = new byte[1024];
        DatagramPacket packet = new DatagramPacket(messageContents, messageContents.length);
        socket.receive(packet);
        message = new String(messageContents);
        return message;

    }  
}

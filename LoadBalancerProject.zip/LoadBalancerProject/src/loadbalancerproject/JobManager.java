
package loadbalancerproject;

import java.util.ArrayList;

public class JobManager {
    
    private static JobManager JobManagerSys = null;

    private JobManager() {

    }

    public static JobManager getJobManager() {
        if(JobManagerSys == null) {
         JobManagerSys = new JobManager();
      }
      return JobManagerSys;
    }
    
    
    //list to store jobs requests
    private ArrayList<Job> jobQueue = new ArrayList();
    
    //method to check if queue is empty
    public boolean jobListVoid() {
        if (jobQueue.size() > 0) {
            return false;
        } else {
            return true;
        }
    }

    //method that adds a job to the list once recevied from client
    public void addJobToQueue(String jobID, String jobRuntime) {
        int absoluteJobID=Integer.parseInt(jobID.trim());
        int absoluteJobRuntime=Integer.parseInt(jobRuntime.trim());
        Job job= new Job(absoluteJobID,absoluteJobRuntime);
        jobQueue.add(job);
    }

    //method to return job message for sending to node
    public String getJobFromQueue() {
        Job job =jobQueue.get(0);
        String jobID = Integer.toString(job.getJobID());
        String jobDuration = Integer.toString(job.getJobRuntime());
        return "JOB, " + jobID + ", " + jobDuration;
    }

    //method to removde job from list once sent to node
    public void removeJobFromQueue() {
        jobQueue.remove(0);
    }
    
}


package loadbalancerproject;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;


public class LBMessagingSystem {
    
    private static LBMessagingSystem LBMessagingSys = null;

    private LBMessagingSystem() {

    }

    public static LBMessagingSystem getMessagingSystem() {
        if (LBMessagingSys == null) {
            LBMessagingSys = new LBMessagingSystem();
        }
        return LBMessagingSys;

    } 
    
    
    private DatagramSocket socket = null; 

    //opens a socket with the specified LB port
    public void setLBPort(int LBPort) throws SocketException {
        socket = new DatagramSocket(LBPort);
    }

    //method for sending messages
    public void sendMessage(String message, InetAddress destIP, int destPort) throws IOException {
        byte[] messageData = new byte[256];
        messageData = message.getBytes();
        DatagramPacket packet = new DatagramPacket(messageData, messageData.length, destIP, destPort);
        socket.send(packet);
    }

    //method for receving messages
    public String receiveMessage() throws IOException {
        byte[] messageData = new byte[256];
        DatagramPacket packet = new DatagramPacket(messageData, messageData.length);
        socket.receive(packet);
        String message = new String(messageData).trim(); //saves message into a string
        return message; //returns an array
    }
    
}

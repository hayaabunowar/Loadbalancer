package loadbalancerproject;

import java.io.IOException;
import java.net.InetAddress;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LoadBalancerProject extends Thread {

    private int LBPortNumber;
    private InetAddress LBIPAddress;
    private int clientPort;
    private InetAddress clientIPAddress;
    private boolean nodesConnected = false;

    //creating one instance of each of the singleton classes
    LBMessagingSystem LBMessagingSys = LBMessagingSystem.getMessagingSystem();
    JobManager jobManager = JobManager.getJobManager();
    NodeManager nodeManagerSys = NodeManager.getNodeManager();

    public LoadBalancerProject() throws IOException {
        super();
    }

    @Override
    public void run() {
        try {
            //opening a socket for communication
            LBMessagingSys.setLBPort(LBPortNumber);

            System.out.println("---------------------------------------------------");
            System.out.println("\tLoad Balancing enabled");
            System.out.println("\tLoad Balancer IP Address: " + LBIPAddress);
            System.out.println("\tListening on port number: " + LBPortNumber);
            System.out.println("---------------------------------------------------");

            //receing messages and sending job requests if job queue is not empty
            while (true) {
                String receivedMessage = LBMessagingSys.receiveMessage();
                messageType(receivedMessage);

                if (!jobManager.jobListVoid() && nodeManagerSys.sendJobToNode(jobManager.getJobFromQueue())) {
                    System.out.println("\nJob being sent to Node " + nodeManagerSys.getNodeID() + ": " + jobManager.getJobFromQueue());
                    jobManager.removeJobFromQueue();
                }
            }
        } catch (InterruptedException | IOException ex) {
            Logger.getLogger(LoadBalancerProject.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //method to sort message based on type
    public void messageType(String receivedMessage) throws IOException, InterruptedException {
        String[] Message = receivedMessage.split(",");
        String[] senderIPAddress = Message[1].split("/");

        switch (Message[0]) {

            case "CLIENT CONNECTION REQUEST":
                System.out.println("\nFROM CLIENT: " + receivedMessage);
                clientIPAddress = InetAddress.getByName(senderIPAddress[1].trim());
                clientPort = Integer.parseInt(Message[2].trim());
                LBMessagingSys.sendMessage("CONNECTED SUCCESSFULLY, ", clientIPAddress, clientPort);
                if (nodesConnected == true) {
                    LBMessagingSys.sendMessage("NODES CONNECTED,", clientIPAddress, clientPort);
                }
                break;
            case "NODE CONNECTION REQUEST":
                System.out.println("\nFROM NODE: " + receivedMessage);
                InetAddress nodeIP = InetAddress.getByName(senderIPAddress[1].trim());
                int nodePort = Integer.parseInt(Message[2].trim());
                int maxThreads = Integer.parseInt(Message[3].trim());
                int nodeID = nodeManagerSys.addNodeToHead(nodeIP, nodePort, maxThreads);
                LBMessagingSys.sendMessage("CONNECTED SUCCESSFULLY, " + nodeID, nodeIP, nodePort);
                System.out.println("CONNECTION TO NODE WITH ID: " + nodeID + " SUCCESSFUL");
                nodesConnected = true;
                if (clientIPAddress != null) {
                    LBMessagingSys.sendMessage("NODES CONNECTED,", clientIPAddress, clientPort);
                }
                break;
            case "JOB":
                System.out.println("\nFROM CLIENT: " + receivedMessage);
                jobManager.addJobToQueue(Message[1], Message[2]);
                break;
            case "JOB FINISHED":
                int nodeID2 = Integer.parseInt(Message[1].trim());
                System.out.println("\nFROM NODE " + nodeID2 + ": " + receivedMessage);
                nodeManagerSys.removeJobFromNode(Integer.parseInt(Message[1].trim()));
                break;
        }
    }

    public int getPort() {
        return LBPortNumber;
    }

    public InetAddress getIP() {
        return LBIPAddress;
    }

    public void setPort(int portNumber) {
        this.LBPortNumber = portNumber;
    }

    public void setIP(InetAddress IPAddress) {
        this.LBIPAddress = IPAddress;
    }

    public static void main(String[] args) {
        try {
            LoadBalancerProject loadBalancer = new LoadBalancerProject();

            if (args.length == 2) {
                loadBalancer.setPort(Integer.parseInt(args[0]));
                loadBalancer.setIP(InetAddress.getByName(args[1]));
            } else {
                loadBalancer.setPort(3000);
                loadBalancer.setIP(InetAddress.getByName("localhost"));
            }
            loadBalancer.start();

        } catch (IOException ex) {
            Logger.getLogger(LoadBalancerProject.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}

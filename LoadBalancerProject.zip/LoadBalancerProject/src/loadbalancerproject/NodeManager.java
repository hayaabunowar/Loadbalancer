package loadbalancerproject;

import java.io.IOException;
import java.net.InetAddress;

public class NodeManager {

    private Node listHead = null;
    private int nodeID = 0;
    private int availableNodes = 0;
    static NodeManager nodeManagerSys = null;

    LBMessagingSystem LBMessagingSys = LBMessagingSystem.getMessagingSystem();

    private NodeManager() {

    }

    public static NodeManager getNodeManager() {
        if (nodeManagerSys == null) {
            nodeManagerSys = new NodeManager();
        }
        return nodeManagerSys;
    }

    //adding a node to the head of the linked list
    public int addNodeToHead(InetAddress nodeIP, int nodePort, int maxJobs) {
        nodeID++;
        Node newNode = new Node(nodeID, maxJobs, nodePort, nodeIP);
        newNode.next = listHead;
        listHead = newNode;
        availableNodes++;
        return nodeID;
    }

    //method that triggers sorting list to send next job request
    public boolean sendJobToNode(String job) throws IOException {
        sortNodesList();
        if (listHead != null) {
            if (listHead.getWeight() > 0) {
                LBMessagingSys.sendMessage(job, listHead.getNodeIP(), listHead.getNodePort());
                listHead.sendJobToNode();
                return true;
            }
        }
        return false;
    }

    //method for sorting the list of nodes based on weight
    public void sortNodesList() {
        if (!((listHead == null) || (listHead.next == null) || (listHead.getWeight() == 1))) {

            Node currentIndex = listHead.next;
            for (int i = 0; i < availableNodes; i++) {
                
                if (listHead.getWeight() < currentIndex.getWeight()) {
                    moveToHead(currentIndex.getNodeID());
                    currentIndex.next = listHead;
                    listHead = currentIndex;
                } else if (listHead.getWeight() == currentIndex.getWeight()) {
                    if (listHead.getThreadsAvailable() < currentIndex.getThreadsAvailable()) {
                        moveToHead(currentIndex.getNodeID());
                        currentIndex.next = listHead;
                        listHead = currentIndex;
                    }
                }
                if (!(currentIndex.next == null)) {
                    currentIndex = currentIndex.next;
                }
            }
        }
    }

    //method to change position of nodes in list
    public void moveToHead(int NodeID) {
        Node currentNode = listHead;
        Node previousNode = listHead;

        while (currentNode.getNodeID() != NodeID) {
            if (currentNode.next == null) {

            } else {
                previousNode = currentNode;

                currentNode = currentNode.next;
            }
        }
        if (currentNode == listHead) {
            listHead = listHead.next;
        } else {
            previousNode.next = currentNode.next;
        }
    }

    //method to remove job from node once a job finished message is received
    public void removeJobFromNode(int NodeID) {
        Node currentNode = listHead;

        while (currentNode.getNodeID() != NodeID) {
            if (currentNode.next != null) {
                currentNode = currentNode.next;
            }
        }

        if (currentNode.getNodeID() == NodeID) {
            currentNode.removeJobFromNode();
        }
    }

    public int getNodeID() {
        return listHead.getNodeID();
    }

}

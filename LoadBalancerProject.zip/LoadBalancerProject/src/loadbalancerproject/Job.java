package loadbalancerproject;

public class Job {

    private int jobID;
    private int jobRuntime;

    Job(int jobID, int jobRuntime) {
        this.jobID = jobID;
        this.jobRuntime = jobRuntime;
    }

    public int getJobID() {
        return jobID;
    }

    public int getJobRuntime() {
        return jobRuntime;
    }

}

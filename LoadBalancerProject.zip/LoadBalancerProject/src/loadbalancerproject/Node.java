
package loadbalancerproject;

import java.net.InetAddress;

public class Node {
    
     private int nodeID;
    private int nodePort;
    private InetAddress nodeIP;
    private double maxThreads;
    private double threadsAvailable;
    private double Weight;
    Node next;

    public Node(int nodeID, double maxJobs, int nodePort, InetAddress nodeIP) {
        this.nodeID = nodeID;
        this.maxThreads = maxJobs;
        this.nodePort = nodePort;
        this.nodeIP = nodeIP;
        this.threadsAvailable = maxJobs;
        this.Weight = 1;
    }

    public void sendJobToNode() {
        threadsAvailable -= 1;
        updateWeight();
    }

    public void removeJobFromNode() {
        threadsAvailable += 1;
        updateWeight();
    }

    private void updateWeight() {
        Weight = threadsAvailable / maxThreads;
    }

    public int getNodeID() {
        return nodeID;
    }

    public InetAddress getNodeIP() {
        return nodeIP;
    }

    public int getNodePort() {
        return nodePort;
    }

    public double getThreadsAvailable() {
        return threadsAvailable;
    }

    public double getWeight() {
        return Weight;
    }
    
}

package nodeproject;

import java.io.IOException;
import java.net.InetAddress;
import java.util.Random;

public class NodeProject extends Thread {

    private int nodeID = 0;

    private int maxJobs;
    private int nodePort;
    private InetAddress nodeIP;
    private int LBPort;
    private InetAddress LBIPAddress;

    //creating instance of messaging system
    NodeMessagingSystem NodeMessagingSys = NodeMessagingSystem.getMessagingSystem();

    NodeProject() throws IOException {
        super();
    }

    @Override
    public void run() {
        try {
            //opening a socket with the nie port set through args
            NodeMessagingSys.setNodePort(nodePort);

            System.out.println("---------------------------------------------------");
            System.out.println("\tNode is now running");
            System.out.println("\tNode IP Address: " + nodeIP);
            System.out.println("\tNode port number: " + nodePort);
            System.out.println("\tNode Max Jobs: " + maxJobs);
            System.out.println("---------------------------------------------------");

            //sending registration message to LB
            System.out.println("\nSENDING CONNECTION REQUEST TO LOAD BALANCER");
            String registrationMessage = "NODE CONNECTION REQUEST, " + nodeIP + ", " + nodePort + ", " + maxJobs;
            NodeMessagingSys.sendMessage(registrationMessage, LBIPAddress, LBPort);

            //receiving messages from LB
            while (true) {
                String receivedMessage = NodeMessagingSys.receiveMessage();
                MessageType(receivedMessage);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    //method to determine type of message received
    public void MessageType(String message) throws IOException, InterruptedException {
        String[] Message = message.split(",");
        switch (Message[0]) {

            case "CONNECTED SUCCESSFULLY":
                System.out.println("CONNECTED TO LOAD BALANCER SUCCESSFULLY");
                nodeID = Integer.parseInt(Message[1].trim());
                System.out.println("NODE SET UP WITH ID:" + nodeID);
                System.out.println("");
                break;

            case "JOB":
                String jobID = Message[1].trim();
                String jobRuntime = Message[2].trim();
                System.out.println("\nJOB ID: " + jobID + " JOB RUNTIME: " + jobRuntime + "s " + "STATUS:RUNNING");
                runJob(jobID, jobRuntime);
                break;
        }
    }

    //method to create a new job thread
    void runJob(String jobID, String jobRuntime) throws IOException {
        int absoluteJobRuntime = Integer.parseInt(jobRuntime);
        int absoluteJobID = Integer.parseInt(jobID);
        JobRunning newJobRunning = new JobRunning(absoluteJobID, absoluteJobRuntime, nodeID, LBIPAddress, LBPort);
        Thread jobThread = new Thread(newJobRunning);
        jobThread.start();
    }

    public void setMaxJobs(int maxJobs) {
        this.maxJobs = maxJobs;
    }

    public void setNodeIP(InetAddress nodeIP) {
        this.nodeIP = nodeIP;
    }

    public void setNodePort(int nodePort) {
        this.nodePort = nodePort;
    }

    public void setLBPort(int LBPort) {
        this.LBPort = LBPort;
    }

    public void setLBIP(InetAddress LBIPAddress) {
        this.LBIPAddress = LBIPAddress;
    }

    public static void main(String[] args) throws IOException {

        NodeProject node = new NodeProject();

        if (args.length == 5) {
            node.setLBPort(Integer.parseInt(args[0]));
            node.setLBIP(InetAddress.getByName(args[1]));
            node.setNodePort(Integer.parseInt(args[2]));
            node.setNodeIP(InetAddress.getByName(args[3]));
            node.setMaxJobs(Integer.parseInt(args[4]));
        } else {
            node.setLBPort(3000);
            node.setLBIP(InetAddress.getByName("localhost"));
            node.setNodePort(4000);
            node.setNodeIP(InetAddress.getByName("localhost"));
            Random rand = new Random();
            node.setMaxJobs(rand.nextInt(6) + 1);
        }
        node.start();

    }

}


package nodeproject;

import java.io.IOException;
import java.net.InetAddress;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JobRunning extends Thread {
    
    private int jobDuration = 0;
    private int nodeID = 0;
    private int jobID;
    private InetAddress LBIPAddress;
    private int LBPort;

    //creating instance of messaging system
    NodeMessagingSystem NodeMessagingSys = NodeMessagingSystem.getMessagingSystem();

    //defining the constructor
    JobRunning(int jobID, int jobDuration, int nodeID, InetAddress LBIPAddress,int LBPort) throws IOException {
        this.jobDuration = jobDuration;
        this.jobID = jobID;
        this.nodeID = nodeID;
        this.LBIPAddress = LBIPAddress;
        this.LBPort=LBPort;
    }

    //method that simulates job processing
    @Override
    public void run() {
        try {
            Thread.sleep(jobDuration * 1000);
            System.out.println("\nJOB ID: " + jobID + " JOB STATUS: FINISHED");
            String finishedMessage = "JOB FINISHED, " + nodeID + ", " + jobID;
            NodeMessagingSys.sendMessage(finishedMessage, LBIPAddress,LBPort);

        } catch (IOException | InterruptedException e) {
            Logger.getLogger(JobRunning.class.getName()).log(Level.SEVERE, null, e);
        }
    } 
}

package nodeproject;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class NodeMessagingSystem {

    static NodeMessagingSystem NodeMessagingSys = null;

    private NodeMessagingSystem() {

    }

    public static NodeMessagingSystem getMessagingSystem() {
        if (NodeMessagingSys == null) {
            NodeMessagingSys = new NodeMessagingSystem();
        }
        return NodeMessagingSys;

    }

    private DatagramSocket socket = null;

    //method to open a socket with the node port
    public void setNodePort(int nodePort) throws SocketException {
        socket = new DatagramSocket(nodePort);
    }

    //method for sending messages to load balancer
    public void sendMessage(String message, InetAddress LBIPAddress, int LBPort) throws IOException {
        byte[] messageData = new byte[256];
        messageData = message.getBytes();
        DatagramPacket packet = new DatagramPacket(messageData, messageData.length, LBIPAddress, LBPort);
        socket.send(packet);
    }

    //method for receiving messages from load balancer
    public String receiveMessage() throws IOException {
        String message = "";
        byte[] messageData = new byte[256];
        DatagramPacket packet = new DatagramPacket(messageData, messageData.length);
        socket.receive(packet);
        message = new String(messageData).trim(); //saves message into a string
        return message;
    }

}
